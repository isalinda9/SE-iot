import time
def somar(x: float, y: float) -> float:
    """Retorna a soma de x e y."""
    return x + y

def subtrair(x: float, y: float) -> float:
    """Retorna a diferença entre x e y."""
    return x - y

def multiplicar(x: float, y: float) -> float:
    """Retorna o produto de x e y."""
    return x * y

def dividir(x: float, y: float):
    """Retorna o quociente de x e y. Trata divisão por zero."""
    if y == 0:
        return "Erro: Divisão por zero não é permitida."
    return x / y

def exibir_menu():
    print("\n--- Calculadora Python ---")
    print("1. Soma (+)")
    print("2. Subtração (-)")
    print("3. Multiplicação (*)")
    print("4. Divisão (/)")
    print("Q. Sair")
    print("--------------------------")

def calculadora():
    while True:
        exibir_menu()
        escolha = input("Escolha a operação (1/2/3/4 ou Q): ").upper()

        if escolha == 'Q':
            print("Encerrando a calculadora. Até logo!")
            break

        if escolha in ('1', '2', '3', '4'):
            try:
                num1 = float(input("Digite o primeiro número: "))
                num2 = float(input("Digite o segundo número: "))
            except ValueError:
                print("Erro: Por favor, insira apenas números válidos.")
                continue

            if escolha == '1':
                print(f"Resultado: {num1} + {num2} = {somar(num1, num2)}")
            elif escolha == '2':
                print(f"Resultado: {num1} - {num2} = {subtrair(num1, num2)}")
            elif escolha == '3':
                print(f"Resultado: {num1} * {num2} = {multiplicar(num1, num2)}")
            elif escolha == '4':
                resultado = dividir(num1, num2)
                if resultado == "Erro: Divisão por zero não é permitida.":
                     print(resultado)
                else:
                    print(f"Resultado: {num1} / {num2} = {resultado}")
        else:
            print("Opção inválida. Tente novamente.")

if __name__ == "__main__":
    calculadora()
