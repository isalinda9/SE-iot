int botao1 = 2;
int botao2 = 3;
int resultado = 0;

void setup() {
  pinMode(botao1, INPUT_PULLUP);
  pinMode(botao2, INPUT_PULLUP);

  Serial.begin(9600);
}

void loop() {

  if (digitalRead(botao1) == LOW) {
    resultado = resultado + 1;
    Serial.println(resultado);
    delay(300);
  }

  if (digitalRead(botao2) == LOW) {
    resultado = resultado + 2;
    Serial.println(resultado);
    delay(300);
  }
}